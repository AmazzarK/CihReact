import React from 'react'

const Footer = () => {
  return (
    <div className='text-center my-4'>Copyright &copy; CIH Bank 2023</div>
  )
}

export default Footer
